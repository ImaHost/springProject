package com.hallabong.faq.vo;

import lombok.Data;

@Data
public class FaqVO {

	private Integer no;
	private String title;
	private String content;
	private String id;
	
}
