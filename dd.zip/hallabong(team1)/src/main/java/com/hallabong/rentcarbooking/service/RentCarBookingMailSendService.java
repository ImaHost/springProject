package com.hallabong.rentcarbooking.service;

public interface RentCarBookingMailSendService {

	public String joinEmail(String email) throws Exception;
}
